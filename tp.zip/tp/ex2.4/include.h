#ifndef TP_SALARY_H
#define TP_SALARY_H

void adjustSalary(double *sal1, double *sal2, double *sal3, double *bonus);

#endif // TP_SALARY_H
