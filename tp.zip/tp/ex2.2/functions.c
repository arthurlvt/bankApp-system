#include <stdio.h>
#include "include.h"

void oppositNbr(int nbr1, int nbr2) {
    nbr1 = -nbr1;
    nbr2 = -nbr2;
}
