# ifndef TP_EX_H
# define TP_EX_H

void oppositNbr(int nbr1, int nbr2);
# endif // TP_EX_H
