#ifndef INCLUDE_H
#define INCLUDE_H

void addOne(int *nbr1, int *nbr2);
#endif // INCLUDE_H
