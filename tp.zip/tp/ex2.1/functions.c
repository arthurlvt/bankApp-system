#include <stdio.h>
#include "include.h"

void addOne(int nbr1, int nbr2) {
    nbr1 ++;
    nbr2 ++;
}