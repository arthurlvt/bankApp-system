#ifndef TP_EX_H
#define TP_EX_H

int modifyValue(int value);
bool isPositive(int value);

#endif // TP_EX_H
