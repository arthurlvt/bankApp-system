#ifndef INCLUDE_H
#define INCLUDE_H
#include <stdbool.h>
bool logicOperation(bool val1, bool val2, bool opp1, bool opp2, bool opp3, bool *resultOR, bool *resultAND, bool *resultXOR);
#endif