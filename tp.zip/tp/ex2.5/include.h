#ifndef TP_EX_H
#define TP_EX_H

#include <stdio.h>

int modify(int *minNbr, int *maxNbr);
int swap(int *minNbr2, int *maxNbr2);

#endif // TP_EX_H